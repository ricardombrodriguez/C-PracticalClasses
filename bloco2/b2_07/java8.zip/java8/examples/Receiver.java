public class Currency {
  public String getCode(Currency this) {
  }
}

